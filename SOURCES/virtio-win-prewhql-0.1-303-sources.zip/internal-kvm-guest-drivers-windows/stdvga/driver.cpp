/*
 * Copyright (c) 2026 Alibaba Cloud Computing Ltd.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met :
 * 1. Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 * 2. Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and / or other materials provided with the distribution.
 * 3. Neither the names of the copyright holders nor the names of their contributors
 *    may be used to endorse or promote products derived from this software
 *    without specific prior written permission.
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS ``AS IS'' AND
 * ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO, THE
 * IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR PURPOSE
 * ARE DISCLAIMED.IN NO EVENT SHALL THE COPYRIGHT HOLDERS OR CONTRIBUTORS BE LIABLE
 * FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL
 * DAMAGES (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS
 * OR SERVICES; LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION)
 * HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 * LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY
 * OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF
 * SUCH DAMAGE.
 */

#include "driver.h"
#include "trace.h"
#include "driver.tmh"

static PDRIVER_OBJECT g_StdVgaDriverObject = NULL;

#pragma code_seg("PAGE")

static NTSTATUS StdVgaDdiAddDevice(_In_ DEVICE_OBJECT *pPhysicalDeviceObject, _Outptr_ PVOID *ppDeviceContext)
{
    PAGED_CODE();

    if (ppDeviceContext == NULL || pPhysicalDeviceObject == NULL)
    {
        TraceEvents(TRACE_LEVEL_WARNING, DBG_ALL, "AddDevice invalid parameter");
        return STATUS_INVALID_PARAMETER;
    }

    PSTDVGA_DEVICE_CONTEXT pCtx = (PSTDVGA_DEVICE_CONTEXT)ExAllocatePoolWithTag(NonPagedPoolNx,
                                                                                sizeof(STDVGA_DEVICE_CONTEXT),
                                                                                STDVGA_TAG);

    if (pCtx == NULL)
    {
        TraceEvents(TRACE_LEVEL_ERROR, DBG_ALL, "AddDevice allocation failed");
        return STATUS_INSUFFICIENT_RESOURCES;
    }
    RtlZeroMemory(pCtx, sizeof(STDVGA_DEVICE_CONTEXT));
    pCtx->pPhysicalDevice = pPhysicalDeviceObject;
    pCtx->AdapterPowerState = PowerDeviceD0;
    pCtx->MonitorPowerState = PowerDeviceD0;

    *ppDeviceContext = pCtx;
    return STATUS_SUCCESS;
}

static NTSTATUS StdVgaDdiRemoveDevice(_In_ PVOID pDeviceContext)
{
    PAGED_CODE();

    if (pDeviceContext != NULL)
    {
        ExFreePoolWithTag(pDeviceContext, STDVGA_TAG);
    }
    return STATUS_SUCCESS;
}

static NTSTATUS StdVgaDdiStartDevice(_In_ PVOID pDeviceContext,
                                     _In_ DXGK_START_INFO *pDxgkStartInfo,
                                     _In_ DXGKRNL_INTERFACE *pDxgkInterface,
                                     _Out_ PULONG pNumberOfVideoPresentSources,
                                     _Out_ PULONG pNumberOfChildren)
{
    PAGED_CODE();
    return StdVgaStartDevice((PSTDVGA_DEVICE_CONTEXT)pDeviceContext,
                             pDxgkStartInfo,
                             pDxgkInterface,
                             pNumberOfVideoPresentSources,
                             pNumberOfChildren);
}

static NTSTATUS StdVgaDdiStopDevice(_In_ PVOID pDeviceContext)
{
    PAGED_CODE();
    return StdVgaStopDevice((PSTDVGA_DEVICE_CONTEXT)pDeviceContext);
}

#pragma code_seg()

static VOID StdVgaDdiResetDevice(_In_ PVOID pDeviceContext)
{
    StdVgaResetDevice((PSTDVGA_DEVICE_CONTEXT)pDeviceContext);
}

#pragma code_seg("PAGE")

static NTSTATUS StdVgaDdiDispatchIoRequest(_In_ PVOID pDeviceContext,
                                           _In_ ULONG VidPnSourceId,
                                           _In_ PVIDEO_REQUEST_PACKET pVideoRequestPacket)
{
    PAGED_CODE();
    return StdVgaDispatchIoRequest((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, VidPnSourceId, pVideoRequestPacket);
}

static NTSTATUS StdVgaDdiSetPowerState(_In_ PVOID pDeviceContext,
                                       _In_ ULONG DeviceUid,
                                       _In_ DEVICE_POWER_STATE DevicePowerState,
                                       _In_ POWER_ACTION ActionType)
{
    PAGED_CODE();
    return StdVgaSetPowerState((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, DeviceUid, DevicePowerState, ActionType);
}

static NTSTATUS StdVgaDdiQueryChildRelations(_In_ PVOID pDeviceContext,
                                             _Inout_ PDXGK_CHILD_DESCRIPTOR pChildRelations,
                                             _In_ ULONG ChildRelationsSize)
{
    PAGED_CODE();
    return StdVgaQueryChildRelations((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pChildRelations, ChildRelationsSize);
}

static NTSTATUS StdVgaDdiQueryChildStatus(_In_ PVOID pDeviceContext,
                                          _Inout_ PDXGK_CHILD_STATUS pChildStatus,
                                          _In_ BOOLEAN NonDestructiveOnly)
{
    PAGED_CODE();
    return StdVgaQueryChildStatus((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pChildStatus, NonDestructiveOnly);
}

static NTSTATUS StdVgaDdiQueryDeviceDescriptor(_In_ PVOID pDeviceContext,
                                               _In_ ULONG ChildUid,
                                               _Inout_ PDXGK_DEVICE_DESCRIPTOR pDeviceDescriptor)
{
    PAGED_CODE();
    return StdVgaQueryDeviceDescriptor((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, ChildUid, pDeviceDescriptor);
}

static NTSTATUS StdVgaDdiQueryAdapterInfo(_In_ PVOID pDeviceContext,
                                          _In_ CONST DXGKARG_QUERYADAPTERINFO *pQueryAdapterInfo)
{
    PAGED_CODE();
    return StdVgaQueryAdapterInfo((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pQueryAdapterInfo);
}

static NTSTATUS StdVgaDdiSetPointerPosition(_In_ PVOID pDeviceContext,
                                            _In_ CONST DXGKARG_SETPOINTERPOSITION *pSetPointerPosition)
{
    PAGED_CODE();
    return StdVgaSetPointerPosition((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pSetPointerPosition);
}

static NTSTATUS StdVgaDdiSetPointerShape(_In_ PVOID pDeviceContext,
                                         _In_ CONST DXGKARG_SETPOINTERSHAPE *pSetPointerShape)
{
    PAGED_CODE();
    return StdVgaSetPointerShape((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pSetPointerShape);
}

static NTSTATUS StdVgaDdiEscape(_In_ PVOID pDeviceContext, _In_ CONST DXGKARG_ESCAPE *pEscape)
{
    PAGED_CODE();
    return StdVgaEscape((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pEscape);
}

static NTSTATUS StdVgaDdiCollectDbgInfo(_In_ PVOID pDeviceContext, _In_ CONST DXGKARG_COLLECTDBGINFO *pCollectDbgInfo)
{
    PAGED_CODE();
    return StdVgaCollectDbgInfo((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pCollectDbgInfo);
}

static NTSTATUS StdVgaDdiIsSupportedVidPn(_In_ PVOID pDeviceContext,
                                          _Inout_ DXGKARG_ISSUPPORTEDVIDPN *pIsSupportedVidPn)
{
    PAGED_CODE();
    return StdVgaIsSupportedVidPn((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pIsSupportedVidPn);
}

static NTSTATUS
StdVgaDdiRecommendFunctionalVidPn(_In_ PVOID pDeviceContext,
                                  _In_ CONST DXGKARG_RECOMMENDFUNCTIONALVIDPN *pRecommendFunctionalVidPn)
{
    PAGED_CODE();
    return StdVgaRecommendFunctionalVidPn((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pRecommendFunctionalVidPn);
}

static NTSTATUS StdVgaDdiRecommendMonitorModes(_In_ PVOID pDeviceContext,
                                               _In_ CONST DXGKARG_RECOMMENDMONITORMODES *pRecommendMonitorModes)
{
    PAGED_CODE();
    return StdVgaRecommendMonitorModes((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pRecommendMonitorModes);
}

static NTSTATUS StdVgaDdiEnumVidPnCofuncModality(_In_ PVOID pDeviceContext,
                                                 _In_ CONST DXGKARG_ENUMVIDPNCOFUNCMODALITY *pEnumCofuncModality)
{
    PAGED_CODE();
    return StdVgaEnumVidPnCofuncModality((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pEnumCofuncModality);
}

static NTSTATUS
StdVgaDdiSetVidPnSourceVisibility(_In_ PVOID pDeviceContext,
                                  _In_ CONST DXGKARG_SETVIDPNSOURCEVISIBILITY *pSetVidPnSourceVisibility)
{
    PAGED_CODE();
    return StdVgaSetVidPnSourceVisibility((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pSetVidPnSourceVisibility);
}

static NTSTATUS StdVgaDdiCommitVidPn(_In_ PVOID pDeviceContext, _In_ CONST DXGKARG_COMMITVIDPN *pCommitVidPn)
{
    PAGED_CODE();
    return StdVgaCommitVidPn((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pCommitVidPn);
}

static NTSTATUS
StdVgaDdiUpdateActiveVidPnPresentPath(_In_ PVOID pDeviceContext,
                                      _In_ CONST DXGKARG_UPDATEACTIVEVIDPNPRESENTPATH *pUpdateActiveVidPnPresentPath)
{
    PAGED_CODE();
    return StdVgaUpdateActiveVidPnPresentPath((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pUpdateActiveVidPnPresentPath);
}

static NTSTATUS StdVgaDdiQueryVidPnHWCapability(_In_ PVOID pDeviceContext,
                                                _Inout_ DXGKARG_QUERYVIDPNHWCAPABILITY *pVidPnHWCaps)
{
    PAGED_CODE();
    return StdVgaQueryVidPnHWCapability((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pVidPnHWCaps);
}

static NTSTATUS StdVgaDdiStopDeviceAndReleasePostDisplayOwnership(_In_ PVOID pDeviceContext,
                                                                  _In_ D3DDDI_VIDEO_PRESENT_TARGET_ID TargetId,
                                                                  _Out_ DXGK_DISPLAY_INFORMATION *pDisplayInfo)
{
    PAGED_CODE();
    return StdVgaStopDeviceAndReleasePostDisplayOwnership((PSTDVGA_DEVICE_CONTEXT)pDeviceContext,
                                                          TargetId,
                                                          pDisplayInfo);
}

#pragma code_seg()

static BOOLEAN StdVgaDdiInterruptRoutine(_In_ PVOID pDeviceContext, _In_ ULONG MessageNumber)
{
    return StdVgaInterruptRoutine((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, MessageNumber);
}

static VOID StdVgaDdiDpcRoutine(_In_ PVOID pDeviceContext)
{
    StdVgaDpcRoutine((PSTDVGA_DEVICE_CONTEXT)pDeviceContext);
}

static NTSTATUS StdVgaDdiSystemDisplayEnable(_In_ PVOID pDeviceContext,
                                             _In_ D3DDDI_VIDEO_PRESENT_TARGET_ID TargetId,
                                             _In_ PDXGKARG_SYSTEM_DISPLAY_ENABLE_FLAGS Flags,
                                             _Out_ PUINT pWidth,
                                             _Out_ PUINT pHeight,
                                             _Out_ D3DDDIFORMAT *pColorFormat)
{
    return StdVgaSystemDisplayEnable((PSTDVGA_DEVICE_CONTEXT)pDeviceContext,
                                     TargetId,
                                     Flags,
                                     pWidth,
                                     pHeight,
                                     pColorFormat);
}

static VOID StdVgaDdiSystemDisplayWrite(_In_ PVOID pDeviceContext,
                                        _In_ PVOID pSource,
                                        _In_ UINT SourceWidth,
                                        _In_ UINT SourceHeight,
                                        _In_ UINT SourceStride,
                                        _In_ UINT PositionX,
                                        _In_ UINT PositionY)
{
    StdVgaSystemDisplayWrite((PSTDVGA_DEVICE_CONTEXT)pDeviceContext,
                             pSource,
                             SourceWidth,
                             SourceHeight,
                             SourceStride,
                             PositionX,
                             PositionY);
}

static VOID StdVgaDdiUnload(VOID)
{
    TraceEvents(TRACE_LEVEL_INFORMATION, DBG_ALL, "DDI:Unload");
    if (g_StdVgaDriverObject != NULL)
    {
        WPP_CLEANUP(g_StdVgaDriverObject);
        g_StdVgaDriverObject = NULL;
    }
}

static NTSTATUS StdVgaDdiQueryInterface(_In_ PVOID pDeviceContext, _In_ PQUERY_INTERFACE pQueryInterface)
{
    UNREFERENCED_PARAMETER(pDeviceContext);
    TraceEvents(TRACE_LEVEL_VERBOSE, DBG_ALL, "DDI:QueryInterface");
    if (pQueryInterface != NULL && pQueryInterface->InterfaceType != NULL)
    {
        char buf[80];
        const GUID *guid = pQueryInterface->InterfaceType;
        RtlStringCchPrintfA(buf,
                            sizeof(buf),
                            "DDI:QI g={%08X-%04X-%04X-%02X%02X-%02X%02X%02X%02X%02X%02X}",
                            guid->Data1,
                            guid->Data2,
                            guid->Data3,
                            guid->Data4[0],
                            guid->Data4[1],
                            guid->Data4[2],
                            guid->Data4[3],
                            guid->Data4[4],
                            guid->Data4[5],
                            guid->Data4[6],
                            guid->Data4[7]);
        TraceEvents(TRACE_LEVEL_VERBOSE, DBG_ALL, "%s", buf);
    }
    return STATUS_NOT_SUPPORTED;
}

//
// KMDOD PresentDisplayOnly: dxgkrnl asks us to copy dirty rectangles from
// system memory to the framebuffer. Defer to the real implementation in
// device.cpp.
//
static NTSTATUS StdVgaDdiPresentDisplayOnly(_In_ PVOID pDeviceContext,
                                            _In_ CONST DXGKARG_PRESENT_DISPLAYONLY *pPresentDisplayOnly)
{
    return StdVgaPresentDisplayOnly((PSTDVGA_DEVICE_CONTEXT)pDeviceContext, pPresentDisplayOnly);
}

static NTSTATUS StdVgaDdiNotifyAcpiEvent(_In_ PVOID pDeviceContext,
                                         _In_ DXGK_EVENT_TYPE EventType,
                                         _In_ ULONG Event,
                                         _In_ PVOID Argument,
                                         _Out_ PULONG pAcpiFlags)
{
    UNREFERENCED_PARAMETER(pDeviceContext);
    UNREFERENCED_PARAMETER(EventType);
    UNREFERENCED_PARAMETER(Event);
    UNREFERENCED_PARAMETER(Argument);
    TraceEvents(TRACE_LEVEL_VERBOSE, DBG_ALL, "DDI:NotifyAcpiEvent");
    if (pAcpiFlags)
    {
        *pAcpiFlags = 0;
    }
    return STATUS_SUCCESS;
}

static VOID StdVgaDdiControlEtwLogging(_In_ BOOLEAN Enable, _In_ ULONG Flags, _In_ UCHAR Level)
{
    UNREFERENCED_PARAMETER(Enable);
    UNREFERENCED_PARAMETER(Flags);
    UNREFERENCED_PARAMETER(Level);
}

static NTSTATUS StdVgaDdiSetPalette(_In_ PVOID pDeviceContext, _In_ CONST DXGKARG_SETPALETTE *pSetPalette)
{
    UNREFERENCED_PARAMETER(pDeviceContext);
    UNREFERENCED_PARAMETER(pSetPalette);
    TraceEvents(TRACE_LEVEL_VERBOSE, DBG_ALL, "DDI:SetPalette");
    return STATUS_SUCCESS;
}

//
// DriverEntry - KMDOD (Display-only) Miniport via DxgkInitializeDisplayOnlyDriver
//
#pragma code_seg("INIT")

extern "C" NTSTATUS DriverEntry(_In_ DRIVER_OBJECT *pDriverObject, _In_ UNICODE_STRING *pRegistryPath)
{
    KMDDOD_INITIALIZATION_DATA InitData = {};

    WPP_INIT_TRACING(pDriverObject, pRegistryPath);
    g_StdVgaDriverObject = pDriverObject;

    InitData.Version = DXGKDDI_INTERFACE_VERSION_WDDM1_3;

    // Adapter lifecycle
    InitData.DxgkDdiAddDevice = StdVgaDdiAddDevice;
    InitData.DxgkDdiStartDevice = StdVgaDdiStartDevice;
    InitData.DxgkDdiStopDevice = StdVgaDdiStopDevice;
    InitData.DxgkDdiRemoveDevice = StdVgaDdiRemoveDevice;
    InitData.DxgkDdiDispatchIoRequest = StdVgaDdiDispatchIoRequest;
    InitData.DxgkDdiInterruptRoutine = StdVgaDdiInterruptRoutine;
    InitData.DxgkDdiDpcRoutine = StdVgaDdiDpcRoutine;

    // Child/monitor
    InitData.DxgkDdiQueryChildRelations = StdVgaDdiQueryChildRelations;
    InitData.DxgkDdiQueryChildStatus = StdVgaDdiQueryChildStatus;
    InitData.DxgkDdiQueryDeviceDescriptor = StdVgaDdiQueryDeviceDescriptor;

    InitData.DxgkDdiSetPowerState = StdVgaDdiSetPowerState;
    InitData.DxgkDdiNotifyAcpiEvent = StdVgaDdiNotifyAcpiEvent;
    InitData.DxgkDdiResetDevice = StdVgaDdiResetDevice;
    InitData.DxgkDdiUnload = StdVgaDdiUnload;
    InitData.DxgkDdiQueryInterface = StdVgaDdiQueryInterface;
    InitData.DxgkDdiControlEtwLogging = StdVgaDdiControlEtwLogging;

    InitData.DxgkDdiQueryAdapterInfo = StdVgaDdiQueryAdapterInfo;
    InitData.DxgkDdiSetPalette = StdVgaDdiSetPalette;
    InitData.DxgkDdiSetPointerPosition = StdVgaDdiSetPointerPosition;
    InitData.DxgkDdiSetPointerShape = StdVgaDdiSetPointerShape;
    InitData.DxgkDdiEscape = StdVgaDdiEscape;
    InitData.DxgkDdiCollectDbgInfo = StdVgaDdiCollectDbgInfo;

    // VidPn
    InitData.DxgkDdiIsSupportedVidPn = StdVgaDdiIsSupportedVidPn;
    InitData.DxgkDdiRecommendFunctionalVidPn = StdVgaDdiRecommendFunctionalVidPn;
    InitData.DxgkDdiEnumVidPnCofuncModality = StdVgaDdiEnumVidPnCofuncModality;
    InitData.DxgkDdiSetVidPnSourceVisibility = StdVgaDdiSetVidPnSourceVisibility;
    InitData.DxgkDdiCommitVidPn = StdVgaDdiCommitVidPn;
    InitData.DxgkDdiUpdateActiveVidPnPresentPath = StdVgaDdiUpdateActiveVidPnPresentPath;
    InitData.DxgkDdiRecommendMonitorModes = StdVgaDdiRecommendMonitorModes;
    InitData.DxgkDdiQueryVidPnHWCapability = StdVgaDdiQueryVidPnHWCapability;

    // KMDOD-specific
    InitData.DxgkDdiPresentDisplayOnly = StdVgaDdiPresentDisplayOnly;
    InitData.DxgkDdiStopDeviceAndReleasePostDisplayOwnership = StdVgaDdiStopDeviceAndReleasePostDisplayOwnership;
    InitData.DxgkDdiSystemDisplayEnable = StdVgaDdiSystemDisplayEnable;
    InitData.DxgkDdiSystemDisplayWrite = StdVgaDdiSystemDisplayWrite;

    NTSTATUS status = DxgkInitializeDisplayOnlyDriver(pDriverObject, pRegistryPath, &InitData);
    if (!NT_SUCCESS(status))
    {
        WPP_CLEANUP(pDriverObject);
        g_StdVgaDriverObject = NULL;
    }

    return status;
}
