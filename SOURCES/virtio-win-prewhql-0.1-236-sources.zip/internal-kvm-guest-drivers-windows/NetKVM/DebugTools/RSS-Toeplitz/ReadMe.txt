========================================================================
    CONSOLE APPLICATION : RSS-Toeplitz
========================================================================

See Toeplitz test vectors at
http://msdn.microsoft.com/en-us/windows/hardware/ff571021

Currently only little endian version.

TODO: measurement and optimization
TODO: big endian when it will be actual
