#if !defined(RESOURCE_H)
#define RESOURCE_H

#define IDR_REG_NETKVM_NOTIFY_OBJECT    1000

#endif
