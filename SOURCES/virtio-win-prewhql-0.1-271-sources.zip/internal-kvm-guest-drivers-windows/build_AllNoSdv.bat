@echo off
setlocal
SET _BUILD_DISABLE_SDV=Yes
SET EWDK11_DIR="d:\ewdk11"
SET WIN10_INF_DIFX_COMPAT=1
call buildAll.bat %*
