makecert.exe -n "CN=Red Hat Inc.,OU=Dev,O=virtio-win" -r -pe -a sha256 -len 4096 -sv Virtio_Win_Red_Hat_CA.pvk Virtio_Win_Red_Hat_CA.cer

pvk2pfx.exe -pvk Virtio_Win_Red_Hat_CA.pvk -spc Virtio_Win_Red_Hat_CA.cer -pfx Virtio_Win_Red_Hat_CA.pfx -po qum5net
