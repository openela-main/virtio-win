@echo off
setlocal
SET _BUILD_DISABLE_SDV=Yes
SET EWDK11_DIR="c:\ewdk11"
call buildAll.bat %*
