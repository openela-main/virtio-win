#ifndef PCH_H
#define PCH_H

#include "targetver.h"

#include <windows.h>
#include <wtsapi32.h>
#include "userenv.h"

#include "log.h"
#include "utils.h"
#include "Service.h"

#endif //PCH_H
