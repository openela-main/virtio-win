https://blogs.msdn.microsoft.com/visualstudio/2010/05/14/a-guide-to-vcxproj-and-props-file-structure/

https://msdn.microsoft.com/en-us/library/cyhcc7zc.aspx - how to detail output window (MSBuild project build output/log verbosity)
https://msdn.microsoft.com/en-us/library/ms171458.aspx - properties $
https://msdn.microsoft.com/en-us/library/ms171453.aspx - elements @ aka ItemGroup
https://msdn.microsoft.com/en-us/library/ms171462.aspx - targets
https://msdn.microsoft.com/en-us/library/ms171466.aspx - tasks
https://msdn.microsoft.com/en-us/library/ms164307.aspx - element Choose
https://msdn.microsoft.com/en-us/library/ms164313.aspx - well known item metadata
https://msdn.microsoft.com/en-us/library/ms171473.aspx - % batching
https://msdn.microsoft.com/en-us/library/ms171474.aspx - % batching
https://msdn.microsoft.com/en-us/library/ms228229.aspx - % batching
https://msdn.microsoft.com/en-us/library/ms171476.aspx - -> transforms
https://msdn.microsoft.com/en-us/library/bb383819.aspx - special characters @,%,$
https://msdn.microsoft.com/en-us/library/dd997067.aspx - comparing propetires and items
