#pragma once

#ifndef _WIN32_WINNT
#define _WIN32_WINNT 0x0501
#endif

#define INITGUID

#include <windows.h>
#include <initguid.h>
#include "public.h"
#include <setupapi.h>
#include <setupapi.h>
#include <winioctl.h>
#include <dbt.h>

#include <conio.h>
#include <stdio.h>
#include <tchar.h>


#include "PnPAll.h"
#include "vioser.h"


